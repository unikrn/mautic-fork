CHANGELOG
=========

* 1.1.0 (2018-02-20)

  * Adding support for Symfony 3 and Symfony 4

* 1.0.1 (2013-10-25)

  * Lower PHP requirement to 5.3.

* 1.0.0 (2013-08-14)

  * Initial release.
