<?php

namespace OAuth2\Model;

class OAuth2RefreshToken extends OAuth2Token implements IOAuth2RefreshToken
{
}
