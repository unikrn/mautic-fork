<?php

namespace OAuth2\Model;

class OAuth2AccessToken extends OAuth2Token implements IOAuth2AccessToken
{
}
