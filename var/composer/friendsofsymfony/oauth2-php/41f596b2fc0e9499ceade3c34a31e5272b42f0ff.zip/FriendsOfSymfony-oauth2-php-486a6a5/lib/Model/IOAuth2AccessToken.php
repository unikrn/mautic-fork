<?php

namespace OAuth2\Model;

interface IOAuth2AccessToken extends IOAuth2Token
{
}
