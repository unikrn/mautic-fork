<?php

namespace OAuth2\Model;

interface IOAuth2RefreshToken extends IOAuth2Token
{
}
