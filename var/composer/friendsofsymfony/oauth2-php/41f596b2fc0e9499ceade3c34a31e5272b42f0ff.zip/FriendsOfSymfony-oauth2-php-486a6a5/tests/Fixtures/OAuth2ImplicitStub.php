<?php

namespace OAuth2\Tests\Fixtures;

use OAuth2\IOAuth2GrantImplicit;

class OAuth2ImplicitStub extends OAuth2StorageStub implements IOAuth2GrantImplicit
{
}
