<?php

namespace Noxlogic\RateLimitBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NoxlogicRateLimitBundle extends Bundle
{
}
