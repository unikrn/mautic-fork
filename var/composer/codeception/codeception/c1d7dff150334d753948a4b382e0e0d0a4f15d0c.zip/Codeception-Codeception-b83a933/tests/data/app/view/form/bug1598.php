<html>
<body>
<div id="field">
    12,345
</div>
</body>
</html>
