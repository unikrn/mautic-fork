<html>
<body>

<form method="post" action="/form/example3?validate=yes">
    <input type="text" name="user" value="" >
</form>

</body>
</html>