<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>grabValueFrom issue</title>
</head>
<body>
<form method="get">
    <input type="text" name="empty" id="empty">
    <textarea name="empty_textarea" id="empty_textarea"></textarea>
    <textarea name="textarea[name][]" id="textarea_with_square_bracket"></textarea>
</form>
</body>
</html>
