<html>
<body>
<form action="/form/complex" method="POST">
    <input type="checkbox" id="id1" name="field[]" value="first" />
    <input type="checkbox" id="id2" name="field[]" value="second" />
    <input type="checkbox" id="id3" name="field[]" value="third" />
    <input type="submit" value="Submit" />
</form>
</body>
</html>