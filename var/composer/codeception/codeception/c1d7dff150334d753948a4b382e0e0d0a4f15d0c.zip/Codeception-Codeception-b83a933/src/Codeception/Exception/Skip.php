<?php
namespace Codeception\Exception;

class Skip extends \PHPUnit\Framework\SkippedTestError
{

}
