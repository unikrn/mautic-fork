# Change Log
All notable changes to this project will be documented in this file.

This project adheres to [Semantic Versioning](http://semver.org/).

## [6.2.0] - 2018-03-28 ##
### Added
- Closes [#454](https://github.com/sendgrid/sendgrid-php/issues/454), PR [#502](https://github.com/sendgrid/sendgrid-php/pull/502): 
Add helper for adding new recipients to your contactdb via a webform, thanks to [Kraig Hufstedler](https://github.com/kraigh) for the PR!

- Closes [#487](https://github.com/sendgrid/sendgrid-php/issues/487), PR [#506](https://github.com/sendgrid/sendgrid-php/pull/506): 
Add helper to get all stats from a specified data range, thanks to [Milos Pejanovic](https://github.com/runz0rd) for the PR!

- Closes [#368](https://github.com/sendgrid/sendgrid-php/issues/368), PR [#511](https://github.com/sendgrid/sendgrid-php/pull/511): 
Add support for commas and semicolns in email name, thanks to [Quentin Ligier](https://github.com/qligier) for the PR!

- Closes [#491](https://github.com/sendgrid/sendgrid-php/issues/491), PR [#493](https://github.com/sendgrid/sendgrid-php/pull/493: 
Allow for setting attachment content from path, thanks to [rparpa](https://github.com/rparpa) for the PR!

## [6.1.0] - 2018-03-27 ##
### Added
- PR [#512](https://github.com/sendgrid/sendgrid-php/pull/512): Omit PHP closing tag in use case sample, thanks to [Sébastien Santoro](https://github.com/dereckson) for the PR!

- PR [#575](https://github.com/sendgrid/sendgrid-php/pull/575): Add an example to the README.md describing how to send emails as html as the content type, thanks to [Benjamin Manford](https://github.com/manfordbenjamin) for the PR!

- Closes [#547](https://github.com/sendgrid/sendgrid-php/issues/547), PR [#549](https://github.com/sendgrid/sendgrid-php/pull/549): 
Added Code Review to Contributing.md, thanks to [tomhorvat](https://github.com/tomhorvat) for the PR!

- PR [#565](https://github.com/sendgrid/sendgrid-php/pull/565): Add PHP 7.1 and 7.2 to Travis build matrix, thanks to [Emir Beganović](https://github.com/emirb) for the PR!

- PR [#577](https://github.com/sendgrid/sendgrid-php/pull/577): Update PHP Version terms, thanks to [Siddhant Sharma](https://github.com/ssiddhantsharma) for the PR!

- Closes [#540](https://github.com/sendgrid/sendgrid-php/issues/540), PR [#543](https://github.com/sendgrid/sendgrid-php/pull/543): 
Feature/split unit tests, thanks to [Owen Voke](https://github.com/pxgamer) for the PR!

- Closes [#441](https://github.com/sendgrid/sendgrid-php/issues/441), PR [#467](https://github.com/sendgrid/sendgrid-php/pull/467): 
Add deploy to heroku button, thanks to [pangaunn](https://github.com/pangaunn) for the PR!

- Closes [#423](https://github.com/sendgrid/sendgrid-php/issues/423), PR [#510](https://github.com/sendgrid/sendgrid-php/pull/510): 
Adding Google App engine installation with composer instructions, thanks to [Nalin Bhardwaj](https://github.com/nalinbhardwaj) for the PR!

- Closes [#541](https://github.com/sendgrid/sendgrid-php/issues/541), PR [#542](https://github.com/sendgrid/sendgrid-php/pull/542): 
Added CodeCov support, thanks to [Owen Voke](https://github.com/pxgamer) for the PR!

- PR [#539](https://github.com/sendgrid/sendgrid-php/pull/539): Rename LICENSE.txt to md, thanks to [Ankit Jain](https://github.com/ankitjain28may) for the PR!

- Closes [#436](https://github.com/sendgrid/sendgrid-php/issues/436), PR [#535](https://github.com/sendgrid/sendgrid-php/pull/535): Add docker development setup, thanks to [Samundra Shrestha](https://github.com/samundra) for the PR!

- Closes [#532](https://github.com/sendgrid/sendgrid-php/issues/532), PR [#537](https://github.com/sendgrid/sendgrid-php/pull/537): Add license date range unit test, thanks to [uppe-r](https://github.com/uppe-r) for the PR!

- Closes [#533](https://github.com/sendgrid/sendgrid-php/issues/533), PR [#536](https://github.com/sendgrid/sendgrid-php/pull/536): Add unittest to check that specific files exist in repo, thanks to [Bertus Steenberg](https://github.com/bertuss) for the PR!

- Closes [#524](https://github.com/sendgrid/sendgrid-php/issues/524), PR [#527](https://github.com/sendgrid/sendgrid-php/pull/527): Created code climate YML file, thanks to [Prashu Chaudhary](https://github.com/prashuchaudhary) for the PR!

- Closes [#520](https://github.com/sendgrid/sendgrid-php/issues/520), PR [#523](https://github.com/sendgrid/sendgrid-php/pull/523): Added sample env file, thanks to [Joey Lee](https://github.com/yeoji) for the PR!

- PR [#519](https://github.com/sendgrid/sendgrid-php/pull/519): Add github PR template, thanks to [Alex](https://github.com/pushkyn) for the PR!

- PR [#513](https://github.com/sendgrid/sendgrid-php/pull/513): Update to PHP 7.0.0 refactor - Fix syntax error in refactor documentation, thanks to [Sébastien Santoro](https://github.com/dereckson) for the PR!

- PR [#505](https://github.com/sendgrid/sendgrid-php/pull/505): Update README.md with additional badges, thanks to [Lalit Vijay](https://github.com/lalitvj) for the PR!

- Closes [#500](https://github.com/sendgrid/sendgrid-php/issues/500), PR [#504](https://github.com/sendgrid/sendgrid-php/pull/504): SEO Friendly Section links, thanks to [Dharma Saputra](https://github.com/ladhadha) for the PR!

- PR [#503](https://github.com/sendgrid/sendgrid-php/pull/503): Added new badges to README.md, thanks to [Alex](https://github.com/myzeprog) for the PR!

- Closes [#492](https://github.com/sendgrid/sendgrid-php/issues/492), PR [#494](https://github.com/sendgrid/sendgrid-php/pull/494): Demonstrate how to review the request body for troubleshooting, thanks to [Alex](https://github.com/myzeprog) for the PR!

- PR [#476](https://github.com/sendgrid/sendgrid-php/pull/476): Update README.md with license information, thanks to [Tarmo Leppänen](https://github.com/tarlepp) for the PR!

- PR [#475](https://github.com/sendgrid/sendgrid-php/pull/475): Add documentation for setting up domain whitelabel, thanks to [Sourav Sarkar](https://github.com/amsourav) for the PR!

- PR [#468](https://github.com/sendgrid/sendgrid-php/pull/463): Changes the recommendation to use composer as recommended source, thanks to [Gabriela D'Ávila Ferrara](https://github.com/gabidavila) for the PR!

- PR [#463](https://github.com/sendgrid/sendgrid-php/pull/463): Add TROUBLESHOOTING.md section about fixing error 415, thanks to [AlbinoDrought](https://github.com/AlbinoDrought) for the PR!

- PR [#456](https://github.com/sendgrid/sendgrid-php/pull/456): Added Code of Conduct, thanks to [Rubemlrm](https://github.com/Rubemlrm) for the PR!

- PR [#439](https://github.com/sendgrid/sendgrid-php/pull/439): Update to PHP 7.0.0 refactor - Removal of Collections, thanks to [Joseph Opanel](https://github.com/jopanel) for the PR!

- PR [#416](https://github.com/sendgrid/sendgrid-php/pull/416): Add release notifications, thanks to [Gabriel Krell](https://github.com/gabrielkrell) for the PR!

- PR [#415](https://github.com/sendgrid/sendgrid-php/pull/415): Updated example.php to fix that there was no way for the sections to get substituted without their being a substition that calls them, thanks to [Kyle Roberts](https://github.com/kylearoberts) for the PR!

### Fixed
- PR [#545](https://github.com/sendgrid/sendgrid-php/pull/545): Fix typo CONTRIBUTING.md, thanks to [thepriefy](https://github.com/thepriefy) for the PR!

- PR [#588](https://github.com/sendgrid/sendgrid-php/pull/588): Fix broken unit tests

- PR [#576](https://github.com/sendgrid/sendgrid-php/pull/576): API level addressing of the string-only in addSubstitution arg rule. Every long integer triggers a bad request, thanks to [Ezequiel Villarreal](https://github.com/saruman) for the PR!

- PR [#517](https://github.com/sendgrid/sendgrid-php/pull/517): Fix typos in USAGE.md, thanks to [Anatoly](https://github.com/anatolyyyyyy) for the PR!

- PR [#530](https://github.com/sendgrid/sendgrid-php/pull/530): Changed the license period., thanks to [Siddhant Sharma](https://github.com/ssiddhantsharma) for the PR!

- PR [#514](https://github.com/sendgrid/sendgrid-php/pull/514): Don't close img tag in HTML, thanks to [Sébastien Santoro](https://github.com/dereckson) for the PR!

- PR [#507](https://github.com/sendgrid/sendgrid-php/pull/507): Fix typos in various files, thanks to [Brandon Smith](https://github.com/brandon93s) for the PR!

- Fixes [#336](https://github.com/sendgrid/sendgrid-php/issues/336), PR [#479](https://github.com/sendgrid/sendgrid-php/pull/479): Incorrect documentation path fixed, thanks to [Valerian Pereira](https://github.com/valerianpereira) for the PR! 

- PR [#465](https://github.com/sendgrid/sendgrid-php/pull/465): Fix typo in README.md, thanks to [shra1cumar](https://github.com/shra1cumar) for the PR!

- PR [#449](https://github.com/sendgrid/sendgrid-php/pull/449): Fix typos in USAGE.md, thanks to [Cícero Pablo](https://github.com/ciceropablo) for the PR!

- PR [#448](https://github.com/sendgrid/sendgrid-php/pull/448): Fix typos in TROUBLESHOOTING.md, thanks to [Cícero Pablo](https://github.com/ciceropablo) for the PR!

- PR [#435](https://github.com/sendgrid/sendgrid-php/pull/435): Change spam_report() to spam_reports() in documentation and examples, thanks to [mrmxs](https://github.com/mrmxs) for the PR!

- PR [#431](https://github.com/sendgrid/sendgrid-php/pull/431): Fixed minor typo during Mail creation, thanks to [joeldixon66](https://github.com/joeldixon66) for the PR!

## [6.0.0] - 2017-06-30 ##
### BREAKING CHANGE
- PR #408: Update Mail constructor to signify which parameters are required for sending all email
- The `Mail()` constructor now requires `$from`, `$subject`, `$to` and `$content` parameters like so: `Mail($from, $subject, $to, $content)`. Those are the minimally required parameters to send an email.
- Thanks to [Casey Wilson](https://github.com/caseyw) for the PR!

## [5.6.2] - 2017-06-29 ##
### Fix
- PR #410: Adding name for ReplyTo for issue #390
- Thanks to [Casey Wilson](https://github.com/caseyw) for the PR!

## [5.6.1] - 2017-06-26 ##
### Fix
- Versioning mistake (forgot the .0 at the end)

## [5.6.0] - 2017-06-26 ##
### Added
- Pull #405: Updating docs and non-composer includes
- Thanks to [Casey Wilson](https://github.com/caseyw) for the PR!

## [5.5.1] - 2017-05-18 ##
### Fixed
- Pull #396: Use `print_r` instead of `echo` on Arrays
- Thanks to [Ryan P.C. McQuen](https://github.com/ryanpcmcquen) for the PR!

## [5.5.0] - 2017-05-04 ##
### Added
- Pull #393: Update [php-http-client](https://github.com/sendgrid/php-http-client) dependency
- [v3.6](https://github.com/sendgrid/php-http-client/releases/tag/v3.6.0): Pass the curlOptions to the client in buildClient
- [v3.7](https://github.com/sendgrid/php-http-client/releases/tag/v3.7.0): Added ability to get headers as associative array

## [5.4.2] - 2017-04-18 ##
### Fixes
- Fixes #292
- Removes Prism file in sendgrid-php.zip

## [5.4.1] - 2017-04-04 ##
### Added
- Pull #373
- PSR1 & PSR2 Conversion
- Thanks to [Braunson Yager](https://github.com/Braunson) for the PR!

## [5.4.0] - 2017-03-16 ##
### Added
- Pull #337
- API level addressing of the string-only custom arg rule
- Thanks to [Chris Schuld](https://github.com/cbschuld) for the PR!

## [5.3.0] - 2017-03-15 ##
### Added
- Pull #367
- UTF8 encoding forced for content value and message subject
- Thanks to [Chris Schuld](https://github.com/cbschuld) for the PR!

## [5.2.3] - 2017-03-03 ##
### Fixed
- Pull #334
- Fixed serialization of empty JSON objects, fixes #332 & #314
- Thanks to [Matthew Dreyer](https://github.com/Dreyer) for the PR!

## [5.2.2] - 2017-03-03 ##
### Fixed
- Pull #323
- Typo 'user' for 'usr'
- Thanks to [Mike Ralphson](https://github.com/MikeRalphson) for the PR!

## [5.2.1] - 2017-03-01 ##
### Fixed
- Pull #353
- Fixed Issue #352
- Relative path fix for background jobs
- Thanks to [Tarcísio Zotelli Ferraz](https://github.com/tarcisiozf) for the PR!

## [5.2.0] - 2017-02-23 ##
### Added
- Pull #346
- Allow passing curlOptions to the client
- Thanks to [Taluu](https://github.com/sendgrid/sendgrid-php/pull/346) for the PR!

## [5.1.2] - 2016-10-11 ##
### Added
- Pull #330, Fixes #320
- Delete subaccounts returns 200 issue resolved
- The fix happened at the [php-http-client](https://github.com/sendgrid/php-http-client/releases/tag/v3.5.1) dependency.
- Thanks to [emil](https://github.com/emilva) for the PR!

## [5.1.1] - 2016-10-11 ##
### Added
- Pull #307, Fixes #276
- Adds phpdoc and style fixes
- Thanks to [Avishkar Autar](https://github.com/aautar) for the PR!

## [5.1.0] - 2016-09-29 ##
### Fixed
- Pull #295: [Upgrade sendgrid/php-http-client](https://github.com/sendgrid/sendgrid-php/pull/295/files)
- This adds getters for certain properties, please see [this pull request](https://github.com/sendgrid/php-http-client/pull/9) for details
- Thanks to [Arjan Keeman](https://github.com/akeeman) for the pull request!

## [5.0.9] - 2016-09-13 ##
### Fixed
- Pull request #289: [Replace "\jsonSerializable" with "\JsonSerializable" ](https://github.com/sendgrid/sendgrid-php/pull/289)
- Thanks to [Issei.M](https://github.com/issei-m) for the pull request!

## [5.0.8] - 2016-08-24 ##
### Added
- Table of Contents in the README
- Added a [USE_CASES.md](https://github.com/sendgrid/sendgrid-php/blob/master/USE_CASES.md) section, with the first use case example for transactional templates

## [5.0.7] - 2016-07-25 ##
### Added
- [Troubleshooting](https://github.com/sendgrid/sendgrid-php/blob/master/TROUBLESHOOTING.md) section

## [5.0.6] - 2016-07-20 ##
### Added
- README updates
- Update introduction blurb to include information regarding our forward path
- Update the v3 /mail/send example to include non-helper usage
- Update the generic v3 example to include non-fluent interface usage

## [5.0.5] - 2016-07-12 ##
### Added
- Update docs, unit tests and examples to include Sender ID

## [5.0.4] - 2016-07-07 ##
### Added
- Tests now mocked automatically against [prism](https://stoplight.io/prism/)

## [5.0.3] - 2016-07-05 ##
### Updated
- Content based on our updated [Swagger/OAI doc](https://github.com/sendgrid/sendgrid-oai)

## [5.0.2] - 2016-07-05 ##
### Added
- Accept: application/json header per https://sendgrid.com/docs/API_Reference/Web_API_v3/How_To_Use_The_Web_API_v3/requests.html

### Updated
- Content based on our updated [Swagger/OAI doc](https://github.com/sendgrid/sendgrid-oai)

## [5.0.1] - 2016-06-17 ##
### Fixed
- Issue with packaged version for non-composer uses

## [5.0.0] - 2016-06-13 ##
### Added
- Breaking change to support the v3 Web API
- New HTTP client
- v3 Mail Send helper

## [v4.0.4] - (2016-02-18) ##
### Added
- Ability to add scopes to API Keys endpoint [POST]

## [v4.0.3] - (2016-02-18) ##
### Added
- API Keys endpoint [PUT]

## [v4.0.2] - (2015-12-15) ##
### Added
- Tests for API Keys endpoint [POST, PATCH, DELETE]

## [v4.0.1] - (2015-12-03) ##
### Fixed
- HTTP 406 Not Acceptable Errors [#177](https://github.com/sendgrid/sendgrid-php/issues/177)

## [v4.0.0] - (2015-10-16) ##
### Added
- Added support for accessing the [SendGrid Web API v3 endpoints](https://sendgrid.com/docs/API_Reference/Web_API_v3/index.html)
- Implemented part of the /api_keys, /groups and /suppressions endpoints

## [v3.2.0] - (2015-05-13) ##

### Added
- Specify Guzzle proxy via [#149](https://github.com/sendgrid/sendgrid-php/pull/149)
- Option to disable exception raising

## [v3.1.0] - (2015-04-27)
### Added
- Support for API keys

## [v3.0.0] - (2015-04-14)
### Fixed
- CC and BCC not working with SMTPAPI To

### Changed
- **Breaking:** A `\SendGrid\Exception` is now raised when response is not 200
- **Breaking:** `addTo` now uses the Web API parameter as opposed to the SMTPAPI Header. Substitutions will most likely break unless you update to use `addSmtpapiTo`
- The library now depends on Guzzle3
- Major refactoring

### Added
- **Breaking:** `send()` now returns an instance of `\SendGrid\Response`
- Numerous missing methods for new functionality
- `addSmtpapiTo` for using the SMTPAPI To

## [v2.2.1] - (2014-01-29)
### Fixed
- Fix turn_off_ssl_verification option via [#123](https://github.com/sendgrid/sendgrid-php/pull/123)

## [v2.2.0] - (2014-01-12)
### Changed
- Remove [Unirest](https://github.com/Mashape/unirest-php/) and replace with native cURL
- Add CHANGELOG.md
