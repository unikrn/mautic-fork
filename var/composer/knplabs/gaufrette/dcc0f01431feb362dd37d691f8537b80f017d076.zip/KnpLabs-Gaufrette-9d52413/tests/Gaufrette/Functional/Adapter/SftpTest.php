<?php

namespace Gaufrette\Functional\Adapter;

use Gaufrette\Adapter\Sftp;

class SftpTest extends FunctionalTestCase
{
}
