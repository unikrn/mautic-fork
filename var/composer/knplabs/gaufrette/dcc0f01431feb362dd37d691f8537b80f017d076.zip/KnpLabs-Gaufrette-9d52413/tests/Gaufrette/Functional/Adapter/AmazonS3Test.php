<?php

namespace Gaufrette\Functional\Adapter;

class AmazonS3Test extends FunctionalTestCase
{
}
