Handlers
========

This document was moved to the standalone library, please see
`<http://jmsyst.com/libs/serializer/master/handlers>`_.