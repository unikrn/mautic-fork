Rackspace regions
=================

Below are the supported regions on the Rackspace network:

+------+-----------+
| code | location  |
+======+===========+
| IAD  | Virginia  |
+------+-----------+
| ORD  | Chicago   |
+------+-----------+
| DFW  | Dallas    |
+------+-----------+
| LON  | London    |
+------+-----------+
| SYD  | Sydney    |
+------+-----------+
| HKG  | Hong Kong |
+------+-----------+
