.. note::

  This feature is only available to Rackspace users.
