CHANGELOG
=========

2.7.0
-----

 * added the component
