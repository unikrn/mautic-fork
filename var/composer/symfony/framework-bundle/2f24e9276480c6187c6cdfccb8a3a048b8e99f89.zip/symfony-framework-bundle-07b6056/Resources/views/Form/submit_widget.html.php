<?php echo $view['form']->block($form, 'button_widget', array('type' => isset($type) ? $type : 'submit')) ?>
