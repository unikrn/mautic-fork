# Registered listeners for event `event1` ordered by descending priority

## Listener 1

- Type: `function`
- Name: `global_function`
- Priority: `255`

## Listener 2

- Type: `closure`
- Priority: `-1`
