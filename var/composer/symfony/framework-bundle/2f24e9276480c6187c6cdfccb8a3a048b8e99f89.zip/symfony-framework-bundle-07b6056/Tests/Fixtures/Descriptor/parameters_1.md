Container parameters
====================

- `array`: `[12,"Hello world!",true]`
- `boolean`: `true`
- `integer`: `12`
- `string`: `Hello world!`