<?php

$container->loadFromExtension('framework', array(
    'property_info' => array(
        'enabled' => true,
    ),
));
