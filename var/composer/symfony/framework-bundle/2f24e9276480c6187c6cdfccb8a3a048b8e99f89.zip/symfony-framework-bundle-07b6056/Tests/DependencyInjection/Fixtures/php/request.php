<?php

$container->loadFromExtension('framework', array(
    'request' => array(
        'formats' => array(),
    ),
));
