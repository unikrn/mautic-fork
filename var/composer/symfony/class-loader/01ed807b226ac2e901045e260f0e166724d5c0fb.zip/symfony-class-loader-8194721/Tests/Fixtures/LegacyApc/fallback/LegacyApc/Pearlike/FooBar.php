<?php

class LegacyApc_Pearlike_FooBar
{
    public static $loaded = true;
}
