<?php

/*
 * foo
 */

namespace Namespaced;

class WithDirMagic
{
    public function getDir()
    {
        return __DIR__;
    }
}
