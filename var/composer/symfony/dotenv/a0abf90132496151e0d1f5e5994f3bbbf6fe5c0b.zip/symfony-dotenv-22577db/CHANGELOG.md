CHANGELOG
=========

3.3.0
-----

 * [BC BREAK] Since v3.3.7, the latest Dotenv files override the previous ones. Real env vars are not affected and are not overridden.
 * added the component
