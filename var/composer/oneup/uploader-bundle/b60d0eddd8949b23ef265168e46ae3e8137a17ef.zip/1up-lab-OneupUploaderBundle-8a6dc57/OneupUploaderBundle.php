<?php

namespace Oneup\UploaderBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OneupUploaderBundle extends Bundle
{
}
