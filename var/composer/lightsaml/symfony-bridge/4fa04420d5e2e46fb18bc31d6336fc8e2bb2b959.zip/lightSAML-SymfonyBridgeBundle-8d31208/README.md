LightSAML Symfony Bridge Bundle
===============================

[![License](https://img.shields.io/packagist/l/lightsaml/symfony-bridge.svg)](https://packagist.org/packages/lightsaml/symfony-bridge)
[![Build Status](https://travis-ci.org/lightSAML/SymfonyBridgeBundle.svg?branch=master)](https://travis-ci.org/lightSAML/SymfonyBridgeBundle)
[![Coverage Status](https://coveralls.io/repos/lightSAML/SymfonyBridgeBundle/badge.svg?branch=master&service=github)](https://coveralls.io/github/lightSAML/SymfonyBridgeBundle?branch=master)
[![HHVM Status](http://hhvm.h4cc.de/badge/lightsaml/symfony-bridge.svg?style=flat)](http://hhvm.h4cc.de/package/lightsaml/symfony-bridge)

LightSAML Symfony Bridge Bundle implements LightSAML build container bridge to the Symfony container.

