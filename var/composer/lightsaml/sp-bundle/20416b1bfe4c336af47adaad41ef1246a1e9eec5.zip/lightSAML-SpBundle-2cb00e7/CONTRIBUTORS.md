CONTRIBUTORS
============

LightSAML is the result of the work of many people who made the code better

 - Milos Tomic tmilos@lightsaml.com
