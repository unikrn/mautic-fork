<?php

class ClassLoaderTest_ClassC
{

}