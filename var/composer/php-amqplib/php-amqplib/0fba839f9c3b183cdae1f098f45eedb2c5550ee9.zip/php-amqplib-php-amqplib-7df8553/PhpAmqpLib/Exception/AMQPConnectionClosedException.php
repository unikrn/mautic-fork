<?php
namespace PhpAmqpLib\Exception;

class AMQPConnectionClosedException extends AMQPRuntimeException
{
}
