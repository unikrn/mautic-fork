<?php
namespace PhpAmqpLib\Exception;

class AMQPHeartbeatMissedException extends AMQPRuntimeException
{
}
