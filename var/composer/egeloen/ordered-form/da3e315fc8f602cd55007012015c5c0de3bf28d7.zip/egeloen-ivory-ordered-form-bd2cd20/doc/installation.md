# Installation

Require the library in your ``composer.json`` file:

``` bash
$ composer require egeloen/ordered-form
```

So easy, you're already ready to play with the library!

The Ivory Ordered Form library follows the [PSR-4 Standard](http://www.php-fig.org/psr/psr-4/). If you prefer install
it manually, it can be autoload by any convenient autoloader.
