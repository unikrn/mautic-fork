# Known limitations

 * The orderer does not support symetric before/after options.
 * The orderer does not support before & after option simultaneously to move other field(s).

There are probably other limitations, if you find one, report it...
