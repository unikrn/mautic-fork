<?php

namespace Recurr\Transformer;

interface TranslatorInterface
{
    public function trans($string);
}
